# Code of Conduct

This project follows the Contributor Covenant v2.1. By participating, you agree to abide by its terms.

Be respectful, kind, and constructive. Harassment, hate speech, or threats will not be tolerated.

See: https://www.contributor-covenant.org/version/2/1/code_of_conduct/
