# Contributing

Thanks for considering contributing!

- Fork the repository
- Create a feature branch
- Open a pull request with a clear description

Please follow the existing code style, add tests for new functionality, and keep changes small and focused.
